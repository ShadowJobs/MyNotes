## quick start 🚀
1. 修改配置文件名称，将密码存放其中
    ```bash
    mv mail_passwd.example mail_passwd
    vim mail_passwd
    ...
    ```
2. 按指示执行，按照指示执行，最终会得到你用于登陆堡垒机的密码组合，即 <邮箱密码><软token>
    ```bash
    sh get_passwd.sh
    ```

## 下一步
得到密码以后,就可以为所欲为。几个简单提示：
- example/Login VPN     :   使用apple script，一键登陆vpn
- example/relay03.sh    :   使用sshpass，一键登陆堡垒机
- example/machine.sh    :   使用expect， 一键登陆内网的任何一台想到达的机器

***注意：如果是新到手的机器，先手动登陆一下VPN和堡垒机***

## 常见问题
2. 为什么example文件夹里的脚本运行报错？  
    example文件夹里的脚本其实是使用的模版，使用的话需要修改一下脚本路径和机器。另外，需要的sshpass工具以及expect工具都需要手动安装一下（每个人使用习惯不一样，所以没在初始化时直接安装），安装方式如下：
    ```bash
    # 安装sshpass
    brew install https://raw.githubusercontent.com/kadwanev/bigboybrew/master/Library/Formula/sshpass.rb

    # 安装expect
    brew install expect
    ```
3. pip3 install 失败了  
    不要在anaconda或者其它虚拟环境执行此脚本～
4. 为啥我打开了“工作台-OTP”，啥反应也没有呢？  
    两个情况比较常见：1. 连接了vpn 2. 使用网线连接而不是Wi-Fi。这两种情况会导致无法正常抓取流量。关闭代理或者改用Wi-Fi即可。（有时需要重启）