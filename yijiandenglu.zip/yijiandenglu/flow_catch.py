import os
import signal
import sys

from mitmproxy import ctx


class getCookie:
    def __init__(self):
        self.num = 0

    def request(self, flow):
        if flow.request.host == "op.linying.com" and flow.request.path == "/code":
            sys.stderr.write(flow.request.cookies["accessproxy_session"])
            sys.stderr.write("\n")
            sys.stderr.write(flow.request.cookies["session"])
            sys.stderr.write("\n")
            sys.stderr.flush()
            os.kill(os.getpid(), signal.SIGKILL)

addons = [
    getCookie()
]