#!/bin/bash

PASS=`sh ../get_passwd.sh`

sshpass -p $PASS ssh linying@relay3.linying.com