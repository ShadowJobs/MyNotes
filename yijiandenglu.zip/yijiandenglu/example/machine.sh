#!/usr/bin/expect
cd ~/work2/shells/yijianbaolei/example 

spawn sh relay03.sh

# expect "Please select system:"
# send "2\n"

expect "Please select device:"
send "2\n"

expect "Please select login user:"
send "1\n"

# expect "~"
# send "ssh web_server@YOUR_MACHINE_HOST\n"

expect EOF

interact