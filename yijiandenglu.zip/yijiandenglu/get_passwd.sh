#!/bin/bash

envInit(){
    username=`users`

    echo "初次使用, 初始化环境.."
    yes | pip3 install mitmproxy

    echo "检查安装情况.."
    install_tmp=`pip3 list --disable-pip-version-check | grep mitmproxy` 
    if [ $? != 0 ];then 
        echo "pip3环境无法安装mitmproxy, 尝试brew安装"
        brew install mitmproxy
        install_tmp_2=`brew list | grep mitmproxy`
        if [ $? != 0 ];then 
            echo "brew安装失败!"
            exit 1
        fi
    fi

    mitmdump 2>1& 
    echo "生成密钥.."
    sleep 5
    ps aux|grep mitmdump|grep -v grep|awk {'print $2'}|xargs kill -9 

    echo "安装证书..请在此输入开机密码(不是邮箱密码!):"
    security -i unlock-keychain /Users/${username}/Library/Keychains/login.keychain-db
    security add-trusted-cert -k /Users/${username}/Library/Keychains/login.keychain-db /Users/${username}/.mitmproxy/mitmproxy-ca-cert.pem
    security lock-keychain /Users/${username}/Library/Keychains/login.keychain
}

refreshCookie(){
    sudo networksetup -setsecurewebproxy "Wi-Fi" 127.0.0.1 8080
    echo "请打开Kim工作台-快手OTP"
    mitmdump -s flow_catch.py "otp.corp.kuaishou.com/code" 2>${SHELL_FOLDER}"/my_cookie" 1>/dev/null

    sudo networksetup -setsecurewebproxystate "Wi-Fi" off
}

getCode(){
    num=0
    accessproxy_session=""
    session=""

    while read line
    do
        num=$[$num+1]
        if [ $num -eq 1 ];then
            accessproxy_session=$line
        elif [ $num -eq 2 ];then
            session=$line
        fi
    done < $SHELL_FOLDER"/my_cookie" 

    host="https://otp.corp.kuaishou.com/api/v1/code"
    user_agent="Kim/0.6.3 Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; AS; rv:11.0)"
    cookie="accessproxy_session=${accessproxy_session};session=${session}"

    otp_code=`curl ${host} -H "Cookie: ${cookie}" -H "User-Agent: ${user_agent}" 2>/dev/null | cut -c10-15`
}

SHELL_FOLDER=$(cd "$(dirname "$0")";pwd)
isExist=`security find-certificate -c mitmproxy 2>&1`

if [ $? != 0 ];then 
    envInit
    refreshCookie
    echo "初始化完成, 请重新执行此脚本"
    exit 1
fi

otp_code=""
getCode

tmp=`grep '^[[:digit:]]*$' <<< ${otp_code}`

if [ $? -eq 1 ];then
    echo "刷新配置..请按要求操作"
    refreshCookie
    echo "刷新完成, 请重新执行此脚本"
    exit 1
fi

passwd=`cat $SHELL_FOLDER"/mail_passwd"`${otp_code}

echo ${passwd}
